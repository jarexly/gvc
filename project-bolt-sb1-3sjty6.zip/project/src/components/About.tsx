import React, { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { FileSearch, Ruler, PenTool, FileCheck } from 'lucide-react';

const consultationSteps = [
  {
    icon: <FileSearch className="w-12 h-12 text-royal-600" />,
    title: 'Initial Consultation',
    description: 'The process begins with an initial consultation where the solar energy company engages with the client to understand their energy needs, goals, and site-specific requirements.'
  },
  {
    icon: <Ruler className="w-12 h-12 text-royal-600" />,
    title: 'Site Assessment and Feasibility Study',
    description: 'The solar energy company conducts a detailed site assessment to determine the feasibility of a solar energy system, and structural considerations.'
  },
  {
    icon: <PenTool className="w-12 h-12 text-royal-600" />,
    title: 'Customized System Design',
    description: 'Based on the site assessment and feasibility study, the solar energy company designs a customized solar system that meets the client\'s specific requirements.'
  },
  {
    icon: <FileCheck className="w-12 h-12 text-royal-600" />,
    title: 'Proposal and Contracting',
    description: 'The solar energy company presents a comprehensive proposal outlining the system design, projected energy savings, financial analysis, and cost estimates.'
  }
];

const efficiencyMetrics = [
  { label: 'Energy Efficiency Solutions', percentage: 95 },
  { label: 'Solar Panel Maintenance and Repair', percentage: 90 },
  { label: 'Grid-Tied Solar Solutions', percentage: 75 }
];

export default function About() {
  const [activeSection, setActiveSection] = useState('Vision');
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const sectionContent = {
    History: 'Our journey began with a mission to harness renewable energy to power communities worldwide. Over the years, we have grown into a trusted name in solar energy, delivering innovative and sustainable solutions.',
    Mission: 'Our mission is to provide clean, reliable, and affordable solar energy solutions to homes and businesses, fostering a greener planet for future generations.',
    Vision: 'We believe in the transformative power of solar energy to create a more sustainable future. Our commitment to quality and customer satisfaction is evident in every project we undertake. From the initial consultation to post-installation support, we work closely with our clients, providing personalized guidance, transparent communication, and exceptional service at every step.'
  };

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About Us</h1>
          <h3 className="text-4xl text-gray-900 mb-4">Investing in the Future</h3>
        </div>

        <div
          ref={ref}
          className={`space-y-20 transition-all duration-1000 ${
            inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="h-[400px]">
              <div className="relative h-full rounded-lg overflow-hidden">
                <img
                  src="https://images.moneycontrol.com/static-mcnews/2022/02/Solar-panels.jpg?impolicy=website&width=1600&height=900"
                  alt="Modern sustainable home"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div>
              <div className="flex space-x-8 mb-8">
                <button
                  className={`${
                    activeSection === 'History'
                      ? 'text-royal-600 border-b-2 border-royal-600'
                      : 'text-gray-500 hover:text-royal-600'
                  }`}
                  onClick={() => setActiveSection('History')}
                >
                  History
                </button>
                <button
                  className={`${
                    activeSection === 'Mission'
                      ? 'text-royal-600 border-b-2 border-royal-600'
                      : 'text-gray-500 hover:text-royal-600'
                  }`}
                  onClick={() => setActiveSection('Mission')}
                >
                  Mission
                </button>
                <button
                  className={`${
                    activeSection === 'Vision'
                      ? 'text-royal-600 border-b-2 border-royal-600'
                      : 'text-gray-500 hover:text-royal-600'
                  }`}
                  onClick={() => setActiveSection('Vision')}
                >
                  Vision
                </button>
              </div>
              <div className="min-h-[120px]">
                <p className="text-lg text-gray-600 leading-relaxed">{sectionContent[activeSection]}</p>
              </div>

              <div className="space-y-4 mt-8">
                {efficiencyMetrics.map((metric, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{metric.label}</span>
                      <span>{metric.percentage}%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full">
                      <div
                        className="h-full bg-royal-600 rounded-full transition-all duration-1000"
                        style={{ width: `${metric.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-12">
            <h2 className="text-3xl font-bold text-center text-gray-900">Our Consultation Process</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {consultationSteps.map((step, index) => (
                <div key={index} className="text-center space-y-4">
                  <div className="flex justify-center">{step.icon}</div>
                  <h3 className="text-xl font-semibold text-gray-900">{step.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}