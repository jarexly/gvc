import React, { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { MessageSquare, Phone, MapPin, Send } from 'lucide-react';

const contactInfo = {
  phone: '+91-9717779625 / +91-9810255492',
  email: 'Kamal@g-vc.com : Aakriti@g-vc.com',
  address: 'E44/3 Block T, Okhla Industrial Estate Phase 2, New Delhi-110020',
  location: { lat: 28.542690, lng: 77.248050 }
};

const MapComponent = () => {
  return (
    <div className="relative h-[300px] bg-gray-50 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <div className="absolute inset-0 flex items-center justify-center p-6 text-center bg-white/95">
        <div>
          <MapPin className="w-10 h-10 text-royal-600 mx-auto mb-3" />
          <p className="text-gray-600 text-sm mb-2">Visit us at:</p>
          <p className="font-medium text-gray-900 text-base mb-3">{contactInfo.address}</p>
          <a
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(contactInfo.address)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center text-sm text-royal-600 hover:text-royal-700 bg-royal-50 px-4 py-2 rounded-full transition-colors"
          >
            Open in Google Maps
            <MapPin className="ml-2 w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    organization: '',
    email: '',
    message: ''
  });

  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create email content
    const emailBody = `
Name: ${formData.name}
Organization: ${formData.organization || 'Not provided'}
Email: ${formData.email}
Message: ${formData.message}
    `;

    // Create mailto link with pre-filled content
    const mailtoLink = `mailto:${contactInfo.email}?subject=New Contact Form Submission&body=${encodeURIComponent(emailBody)}`;
    
    // Open default email client
    window.location.href = mailtoLink;
    
    // Reset form
    setFormData({
      name: '',
      organization: '',
      email: '',
      message: ''
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Get in Touch</h2>
          <p className="text-lg text-gray-600">Let's discuss how we can help you achieve your sustainable goals</p>
        </div>

        <div ref={ref} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 transition-all duration-1000 ${
          inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}>
          {/* Contact Form */}
          <div className="bg-white rounded-lg shadow-lg p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-royal-500 focus:ring-royal-500"
                />
              </div>

              <div>
                <label htmlFor="organization" className="block text-sm font-medium text-gray-700">Organization</label>
                <input
                  type="text"
                  id="organization"
                  name="organization"
                  value={formData.organization}
                  onChange={handleChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-royal-500 focus:ring-royal-500"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-royal-500 focus:ring-royal-500"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message *</label>
                <textarea
                  id="message"
                  name="message"
                  required
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-royal-500 focus:ring-royal-500"
                />
              </div>

              <button
                type="submit"
                className="w-full flex justify-center items-center px-4 py-3 border border-transparent text-base font-medium rounded-md text-white bg-royal-600 hover:bg-royal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-royal-500"
              >
                Send Message
                <Send className="ml-2 h-4 w-4" />
              </button>
            </form>
          </div>

          {/* Contact Information and Map */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-royal-600 mr-3" />
                  <span className="text-sm">{contactInfo.phone}</span>
                </div>
                <div className="flex items-center">
                  <MessageSquare className="h-5 w-5 text-royal-600 mr-3" />
                  <span className="text-sm">{contactInfo.email}</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-royal-600 mr-3" />
                  <span className="text-sm">{contactInfo.address}</span>
                </div>
              </div>
            </div>

            <MapComponent />
          </div>
        </div>
      </div>
    </section>
  );
}