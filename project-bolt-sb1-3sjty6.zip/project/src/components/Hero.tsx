import React from 'react';
import { ChevronRight } from 'lucide-react';
import { Link } from 'react-scroll';

const slides = [
  {
    title: "Investing in the future",
    subtitle: "Building sustainable tomorrow through smart investments today",
    image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
  },
  {
    title: "Renew, Recycle, Reduce",
    subtitle: "Leading the way in sustainable business practices",
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=2070"
  },
  {
    title: "Global Impact",
    subtitle: "Creating positive change across continents",
    image: "https://plus.unsplash.com/premium_photo-1678743133487-d501f3b0696b?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
  }
];

export default function Hero() {
  const [currentSlide, setCurrentSlide] = React.useState(0);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="home" className="relative min-h-screen w-full overflow-hidden pt-20">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            currentSlide === index ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="absolute inset-0 bg-black/50" />
          <img
            src={slide.image}
            alt={slide.title}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center px-4">
            <div className="text-center text-white">
              <h1 className="text-4xl md:text-5xl lg:text-7xl font-bold mb-4 md:mb-6 tracking-tight">
                {slide.title}
              </h1>
              <p className="text-lg md:text-xl lg:text-2xl mb-8 md:mb-12 max-w-2xl mx-auto">
                {slide.subtitle}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  to="contact"
                  spy={true}
                  smooth={true}
                  offset={-64}
                  duration={500}
                  className="inline-flex items-center px-6 py-3 md:px-8 md:py-4 text-base md:text-lg font-semibold text-white bg-royal-600 rounded-lg hover:bg-royal-700 transition-colors cursor-pointer"
                >
                  Get Started
                  <ChevronRight className="ml-2" size={20} />
                </Link>
                <Link
                  to="about"
                  spy={true}
                  smooth={true}
                  offset={-64}
                  duration={500}
                  className="inline-flex items-center px-6 py-3 md:px-8 md:py-4 text-base md:text-lg font-semibold text-royal-600 bg-white rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  Learn More
                  <ChevronRight className="ml-2" size={20} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      ))}
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-colors ${
              currentSlide === index ? 'bg-white' : 'bg-white/50'
            }`}
          />
        ))}
      </div>
    </section>
  );
}