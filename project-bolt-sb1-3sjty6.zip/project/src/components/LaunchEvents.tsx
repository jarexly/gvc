import React, { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { Calendar, ArrowRight } from 'lucide-react';

export default function LaunchEvents() {
  const [email, setEmail] = useState('');
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Launch events signup:', email);
    setEmail('');
  };

  return (
    <section className="py-20 bg-royal-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          ref={ref}
          className={`text-center transition-all duration-1000 ${
            inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="max-w-3xl mx-auto">
            <Calendar className="w-12 h-12 text-royal-400 mx-auto mb-6" />
            <h2 className="text-4xl font-bold text-white mb-4">Join Our Launch Events</h2>
            <p className="text-lg text-royal-100 mb-8">
              Be the first to know about our exclusive launch events and investment opportunities. Connect with industry leaders and discover sustainable solutions.
            </p>
            
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email for event invitations"
                className="flex-1 px-4 py-3 rounded-lg text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-royal-500"
                required
              />
              <button
                type="submit"
                className="px-6 py-3 bg-royal-500 text-white rounded-lg font-semibold hover:bg-royal-400 transition-colors flex items-center justify-center"
              >
                Get Invited
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </form>
            
            <p className="text-sm text-royal-200 mt-4">
              Limited seats available for our upcoming launch events
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}