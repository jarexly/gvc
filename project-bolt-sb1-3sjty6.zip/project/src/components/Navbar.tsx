import React, { useState } from 'react';
import { Link as ScrollLink } from 'react-scroll';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const navItems = [
  { name: 'Home', to: 'home' },
  { name: 'About Us', to: 'about' },
  { name: 'Services', to: 'services' },
  { name: 'Projects', to: 'projects' }
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const isHomePage = location.pathname === '/';

  const NavLink = ({ item }) => {
    const linkClass =
      'px-3 py-2 text-sm font-medium text-gray-700 hover:text-royal-600 transition-colors duration-300 cursor-pointer';
    
    if (isHomePage) {
      return (
        <ScrollLink
          to={item.to}
          spy={true}
          smooth={true}
          offset={-80}
          duration={500}
          className={linkClass}
          onClick={() => setIsOpen(false)}
        >
          {item.name}
        </ScrollLink>
      );
    }
    return (
      <RouterLink
        to={`/#${item.to}`}
        className={linkClass}
        onClick={() => setIsOpen(false)}
      >
        {item.name}
      </RouterLink>
    );
  };

  const ContactButton = () => {
    const buttonClass =
      'w-full sm:w-auto px-6 py-2.5 text-sm font-medium text-white bg-royal-600 rounded-lg hover:bg-royal-700 transition-colors flex items-center justify-center duration-300 cursor-pointer';
    
    if (isHomePage) {
      return (
        <ScrollLink
          to="contact"
          spy={true}
          smooth={true}
          offset={-80}
          duration={500}
          className={buttonClass}
          onClick={() => setIsOpen(false)}
        >
          Contact
        </ScrollLink>
      );
    }
    return (
      <RouterLink
        to="/#contact"
        className={buttonClass}
        onClick={() => setIsOpen(false)}
      >
        Contact
      </RouterLink>
    );
  };

  return (
    <nav className="fixed w-full z-50 bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <RouterLink to="/" className="flex-shrink-0 flex items-center cursor-pointer">
            <img
              src="https://img1.wsimg.com/isteam/ip/553ac483-0c16-4995-bc17-f0ae0240b51e/logo-png.png/:/rs=w:791,h:200,cg:true,m/cr=w:791,h:200/qt=q:95"
              alt="GVC Logo"
              className="h-16 w-auto"
            />
          </RouterLink>
          
          <div className="hidden md:flex md:items-center md:space-x-6">
            <div className="flex items-center space-x-4">
              {navItems.map((item) => (
                <NavLink key={item.name} item={item} />
              ))}
            </div>
            <ContactButton />
          </div>
          
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-royal-600 focus:outline-none transition-colors duration-300 cursor-pointer"
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div 
        className={`md:hidden absolute w-full transform transition-all duration-300 ease-in-out ${
          isOpen ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none'
        }`}
      >
        <div className="px-4 pt-2 pb-3 space-y-2 bg-white shadow-lg">
          {navItems.map((item) => (
            <div key={item.name} className="block py-2">
              <NavLink item={item} />
            </div>
          ))}
          <div className="pt-2">
            <ContactButton />
          </div>
        </div>
      </div>
    </nav>
  );
}