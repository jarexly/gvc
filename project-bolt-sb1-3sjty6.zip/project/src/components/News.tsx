import React from 'react';
import { useInView } from 'react-intersection-observer';
import { Calendar, ArrowRight } from 'lucide-react';

const news = [
  {
    date: '2024-03-15',
    title: 'EcoInvest Launches New Sustainable Fund',
    excerpt: 'Introducing our latest investment vehicle focused on renewable energy technologies.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1472'
  },
  {
    date: '2024-03-10',
    title: 'Partnership with Global Green Initiative',
    excerpt: 'Strategic alliance formed to accelerate sustainable development projects worldwide.',
    image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&q=80&w=1472'
  },
  {
    date: '2024-03-05',
    title: 'Sustainability Award 2024',
    excerpt: 'EcoInvest recognized for outstanding contribution to environmental conservation.',
    image: 'https://images.unsplash.com/photo-1507878866276-a947ef722fee?auto=format&fit=crop&q=80&w=1472'
  }
];

export default function News() {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section id="news" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Latest News</h2>
          <p className="text-lg text-gray-600">Stay updated with our latest developments</p>
        </div>

        <div 
          ref={ref}
          className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 transition-all duration-1000 ${
            inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {news.map((item, index) => (
            <article key={index} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="relative h-48">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-2">
                  <Calendar className="w-4 h-4 mr-2" />
                  {new Date(item.date).toLocaleDateString()}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600 mb-4">{item.excerpt}</p>
                <button className="inline-flex items-center text-emerald-600 hover:text-emerald-700 transition-colors">
                  Read More <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}