import React, { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { Leaf, TrendingUp, Shield, Recycle, Sun, DollarSign, Briefcase } from 'lucide-react';

const servicesData = {
  Renewable: [
    {
      icon: <Sun className="w-8 h-8" />,
      title: 'Renewable Energy Consulting',
      description: 'Expert guidance to meet your renewable energy needs with tailored strategies.'
    },
    {
      icon: <Recycle className="w-8 h-8" />,
      title: 'Site Visits & Assessments',
      description: 'Comprehensive site evaluations to ensure optimal placement and efficiency of renewable systems.'
    },
    {
      icon: <Leaf className="w-8 h-8" />,
      title: 'Power Purchase Agreements (PPA)',
      description: 'Structured PPA services to facilitate sustainable energy procurement for your projects.'
    },
    {
      icon: <Briefcase className="w-8 h-8" />,
      title: 'Project Tailoring & Management',
      description: 'End-to-end management ensuring each renewable project is customized to your specific needs.'
    }
  ],
  Financial: [
    {
      icon: <DollarSign className="w-8 h-8" />,
      title: 'Financial Consultation',
      description: 'Strategic financial advice to support your investments in renewable energy projects.'
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Market Analysis',
      description: 'In-depth market research to identify and capitalize on optimal investment opportunities.'
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Risk Management',
      description: 'Advanced strategies to assess and mitigate risks associated with your financial investments.'
    },
    {
      icon: <Briefcase className="w-8 h-8" />,
      title: 'Full Cycle Consulting',
      description: 'Comprehensive financial consulting from initial planning to project completion.'
    }
  ]
};

export default function Services() {
  const [activeTab, setActiveTab] = useState('Renewable');
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const renderServices = (services) => (
    services.map((service, index) => (
      <div
        key={index}
        className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
      >
        <div className="text-royal-600 mb-4">{service.icon}</div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
        <p className="text-gray-600">{service.description}</p>
      </div>
    ))
  );

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Comprehensive solutions tailored to your sustainable investment needs
          </p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-12">
          {Object.keys(servicesData).map((category) => (
            <button
              key={category}
              onClick={() => setActiveTab(category)}
              className={`mx-2 px-6 py-2 rounded-full font-medium transition-colors 
                ${
                  activeTab === category
                    ? 'bg-royal-600 text-white'
                    : 'bg-white text-gray-700 border border-gray-300'
                }
                hover:bg-royal-500 hover:text-white
              `}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div 
          ref={ref}
          className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 transition-all duration-1000 ${
            inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {renderServices(servicesData[activeTab])}
        </div>
      </div>
    </section>
  );
}