export interface Project {
  id: string;
  title: string;
  category: string;
  image: string;
  description: string;
  fullDescription: string;
  goals: string[];
  impact: string[];
  timeline: string;
}

export const projects: Project[] = [
  {
    id: 'solar-energy-case-study',
    title: 'Commercial Solar Installation',
    category: 'Solar Energy',
    image: 'https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=2072',
    description: '2MW Solar Installation for Manufacturing Facility',
    fullDescription: 'A comprehensive commercial solar installation project for a large manufacturing facility in Delhi NCR. The project showcases our expertise in designing and implementing large-scale solar solutions that significantly reduce operational costs while promoting sustainable energy practices.',
    goals: [
      'Design and install 2MW solar power system',
      'Reduce client\'s energy costs by 60%',
      'Achieve ROI within 4 years',
      'Implement smart monitoring systems for optimal performance'
    ],
    impact: [
      'Financial: ₹1.8 Crore annual energy cost savings',
      'Environmental: 2,500 metric tons CO2 reduction annually',
      'Operational: 85% energy independence achieved',
      'Innovation: Smart monitoring system implemented for real-time performance tracking'
    ],
    timeline: '2023-2024'
  },
  {
    id: 'ppf-consulting-case',
    title: 'PPF Investment Strategy',
    category: 'Financial Consulting',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=2070',
    description: 'Strategic PPF Portfolio Management for High-Net-Worth Client',
    fullDescription: 'A detailed case study of our PPF (Public Provident Fund) consulting services for a high-net-worth client, demonstrating our expertise in maximizing tax benefits and creating long-term wealth through strategic PPF investments.',
    goals: [
      'Optimize PPF investment strategy for maximum returns',
      'Structure tax-efficient investment plan',
      'Create long-term wealth accumulation strategy',
      'Integrate PPF with overall investment portfolio'
    ],
    impact: [
      'Financial: Enhanced returns through strategic timing of investments',
      'Tax Benefits: Optimized tax savings under Section 80C',
      'Portfolio Growth: 12% effective annual returns achieved',
      'Risk Management: Balanced portfolio with secure government backing'
    ],
    timeline: '2023-2024'
  },
  {
    id: 'industrial-solar-project',
    title: 'Industrial Solar Integration',
    category: 'Solar Energy',
    image: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&q=80&w=1472',
    description: 'Comprehensive Solar Solution for Industrial Complex',
    fullDescription: 'An innovative solar energy integration project for a large industrial complex, featuring advanced energy storage solutions and smart grid technology. This project demonstrates our capability to handle complex industrial-scale renewable energy implementations.',
    goals: [
      'Install 5MW solar capacity with storage',
      'Implement smart grid integration',
      'Achieve 70% energy independence',
      'Reduce peak load by 40%'
    ],
    impact: [
      'Financial: ₹4.2 Crore annual cost reduction',
      'Technical: Successfully integrated with existing power infrastructure',
      'Environmental: 6,000 metric tons CO2 reduction annually',
      'Operational: Enhanced energy reliability with storage solutions'
    ],
    timeline: '2024-2025'
  }
];