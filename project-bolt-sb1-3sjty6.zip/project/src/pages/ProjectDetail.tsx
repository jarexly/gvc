import React, { useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { projects } from '../data/projects';
import { ArrowLeft, Calendar, Target, Award, X } from 'lucide-react';

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const project = projects.find(p => p.id === id);
  const contentRef = useRef<HTMLDivElement>(null);
  const scrollPosition = useRef(0);

  useEffect(() => {
    // Store current scroll position
    scrollPosition.current = window.scrollY;
    // Prevent body scroll when modal is open
    document.body.style.overflow = 'hidden';
    
    return () => {
      // Restore scroll position and body scroll on unmount
      document.body.style.overflow = 'unset';
      window.scrollTo(0, scrollPosition.current);
    };
  }, []);

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Project not found</h2>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center text-royal-600 hover:text-royal-700"
          >
            <ArrowLeft className="mr-2" /> Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 overflow-y-auto">
      <div className="min-h-screen px-4 flex items-start justify-center py-16">
        <div 
          ref={contentRef}
          className="relative w-full max-w-7xl bg-white rounded-lg shadow-xl"
        >
          {/* Close button */}
          <button
            onClick={() => navigate('/')}
            className="absolute top-4 right-4 z-10 p-2 bg-white/90 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X size={24} className="text-gray-600" />
          </button>

          <div className="relative h-[40vh] md:h-[50vh]">
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover rounded-t-lg"
            />
            <div className="absolute inset-0 bg-black/50 rounded-t-lg" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-white px-4">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">{project.title}</h1>
                <p className="text-xl">{project.category}</p>
              </div>
            </div>
          </div>

          <div className="p-6 md:p-8 lg:p-10">
            <button
              onClick={() => navigate('/')}
              className="inline-flex items-center text-royal-600 hover:text-royal-700 mb-8"
            >
              <ArrowLeft className="mr-2" /> Back to Projects
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              <div className="lg:col-span-2">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Overview</h2>
                <p className="text-lg text-gray-600 mb-8">{project.fullDescription}</p>

                <h3 className="text-2xl font-bold text-gray-900 mb-4">Project Goals</h3>
                <ul className="space-y-4 mb-8">
                  {project.goals.map((goal, index) => (
                    <li key={index} className="flex items-start">
                      <Target className="w-6 h-6 text-royal-600 mr-3 flex-shrink-0 mt-1" />
                      <span className="text-gray-600">{goal}</span>
                    </li>
                  ))}
                </ul>

                <h3 className="text-2xl font-bold text-gray-900 mb-4">Impact</h3>
                <ul className="space-y-4">
                  {project.impact.map((impact, index) => (
                    <li key={index} className="flex items-start">
                      <Award className="w-6 h-6 text-royal-600 mr-3 flex-shrink-0 mt-1" />
                      <span className="text-gray-600">{impact}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="lg:col-span-1">
                <div className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Project Details</h3>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <Calendar className="w-5 h-5 text-royal-600 mr-3" />
                      <div>
                        <p className="text-sm text-gray-500">Timeline</p>
                        <p className="text-gray-900">{project.timeline}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
